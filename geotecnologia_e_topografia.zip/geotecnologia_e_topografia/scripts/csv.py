from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFeatureSink,
    QgsFeature,
    QgsGeometry,
    QgsFields,
    QgsField,
    QgsWkbTypes,
    QgsFeatureSink,
    QgsCoordinateReferenceSystem
)

import os
import csv


class CsvWktParaLinhas(QgsProcessingAlgorithm):

    INPUT_FOLDER = 'INPUT_FOLDER'
    OUTPUT = 'OUTPUT'

    def name(self):
        return 'csv_wkt_para_linhas'

    def displayName(self):
        return 'CSV WKT para Linhas (com atributos)'

    def group(self):
        return 'Tereos'

    def groupId(self):
        return 'Tereos'

    def shortHelpString(self):
        return 'Converte CSV com WKT em linhas mantendo todos os atributos.'

    def createInstance(self):
        return CsvWktParaLinhas()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER,
                'Pasta com CSVs',
                behavior=QgsProcessingParameterFile.Folder
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                'Saída (linhas)'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        folder = self.parameterAsString(parameters, self.INPUT_FOLDER, context)

        csv_files = [f for f in os.listdir(folder) if f.lower().endswith('.csv')]

        if not csv_files:
            raise Exception('Nenhum CSV encontrado')

        fields = None
        sink = None
        dest_id = None

        total = len(csv_files)

        for i, file in enumerate(csv_files):

            if feedback.isCanceled():
                break

            feedback.setProgress(int((i / total) * 100))
            feedback.pushInfo(f'Processando: {file}')

            full_path = os.path.join(folder, file)

            with open(full_path, newline='', encoding='utf-8') as f:

                sample = f.read(2048)
                f.seek(0)

                try:
                    dialect = csv.Sniffer().sniff(sample)
                except:
                    dialect = csv.excel

                reader = csv.DictReader(f, dialect=dialect)

                if not reader.fieldnames:
                    continue

                # detectar coluna WKT
                wkt_field = None
                for fn in reader.fieldnames:
                    if fn and fn.strip().lower() == 'wkt':
                        wkt_field = fn
                        break

                if not wkt_field:
                    feedback.pushInfo(f'Sem WKT: {file}')
                    continue

                # cria estrutura de campos UMA VEZ (baseado no primeiro CSV válido)
                if fields is None:
                    fields = QgsFields()

                    for fn in reader.fieldnames:
                        fields.append(QgsField(fn, QVariant.String))

                    fields.append(QgsField('arquivo', QVariant.String))

                    (sink, dest_id) = self.parameterAsSink(
                        parameters,
                        self.OUTPUT,
                        context,
                        fields,
                        QgsWkbTypes.LineString,
                        QgsCoordinateReferenceSystem('EPSG:4326')
                    )

                    if sink is None:
                        raise Exception('Erro ao criar saída')

                count = 0

                for row in reader:

                    wkt = row.get(wkt_field)

                    if not wkt:
                        continue

                    if 'LINESTRING' not in wkt.upper():
                        continue

                    geom = QgsGeometry.fromWkt(wkt)

                    if not geom or geom.isEmpty():
                        continue

                    feat = QgsFeature()
                    feat.setGeometry(geom)
                    feat.setFields(fields)

                    # preenche TODOS os campos
                    for fn in reader.fieldnames:
                        feat[fn] = str(row.get(fn))

                    feat['arquivo'] = file

                    sink.addFeature(feat, QgsFeatureSink.FastInsert)
                    count += 1

                feedback.pushInfo(f'{file}: {count} linhas')
                

        if sink is None:
            raise Exception('Nenhum dado válido encontrado.')

        return {self.OUTPUT: dest_id}
    
    def flags(self):
        # Isso diz ao QGIS para manter o algoritmo funcionando, 
        # mas oculto da Caixa de Ferramentas principal.
        return super().flags() | QgsProcessingAlgorithm.FlagHideFromToolbox
